﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_submit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_fname.Text.Trim()) || txt_fname.Text.Trim().Length < 3 )
            {
                MessageBox.Show("Please enter your full name");
            }

            if (txt_pass.Text != txt_cpass.Text)
            {
                MessageBox.Show("Enter same password for confirmation");
            }


        }
    }
}
