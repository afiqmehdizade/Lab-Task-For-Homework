﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HotelApp.Sattar.DAL
{
    

    class Bae
    {
        protected SqlConnection conn;

        public Bae()
        {
            conn = new SqlConnection(Properties.Settings.Default.CourseDB);
        }
    }
}
