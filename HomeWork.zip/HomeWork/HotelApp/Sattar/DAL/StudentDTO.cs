﻿using HotelApp.Sattar.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelApp.Sattar.DAL
{
    class StudentDTO : Bae
    {

        public bool Create(Student student)
        {
            conn.Open();
            string query = "INSERT INTO Students(Firstname, Lastname, Email, GroupId) VALUES(@fname, @lname,@email, @gid)";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@fname", student.Firstname);
            command.Parameters.AddWithValue("@lname", student.Lastname);
            command.Parameters.AddWithValue("@email", student.Email);
            command.Parameters.AddWithValue("@gid", student.GroupId);

            int rowaffected = command.ExecuteNonQuery();

            conn.Close();

            if (rowaffected > 0)
            {
                return true;
            }

            return false;
        }

        public void Read()
        {

        }
        public void ReadAll()
        {

        }


        public void Update()
        {

        }

        public void Delete()
        {

        }
    }
}
