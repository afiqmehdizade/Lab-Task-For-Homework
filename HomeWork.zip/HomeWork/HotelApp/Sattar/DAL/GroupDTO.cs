﻿using HotelApp.Sattar.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelApp.Sattar.DAL
{
    class GroupDTO : Bae
    {


        public bool Create(Group group)
        {
            conn.Open();
            string query = "INSERT INTO Students(Firstname, Lastname, Email, GroupId) VALUES(@fname, @lname,@email, @gid)";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@fname", group.Name);

            int rowaffected = command.ExecuteNonQuery();

            conn.Close();

            if (rowaffected > 0)
            {
                return true;
            }

            return false;
        }

        public void Read()
        {

        }
        public List<Group> ReadAll()
        {
            List<Group> groups = new List<Group>();

            conn.Open();
            string query = "SELECT * FROM Groups";
            SqlCommand command = new SqlCommand(query, conn);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Group g = new Group
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    RoomId = reader.GetInt32(2)
                };
                groups.Add(g);

            }

            conn.Close();
            return groups;
        }

        public int GetIdByName(string name)
        {
            int id = 0;
            conn.Open();
            string query = "SELECT * FROM Groups WHERE Name=@name";
            SqlCommand command = new SqlCommand(query, conn);
            command.Parameters.AddWithValue("@name", name);
            id = (int)command.ExecuteScalar();

            conn.Close();

            return id;
        }


        public void Update()
        {

        }

        public void Delete()
        {

        }
    }
}
