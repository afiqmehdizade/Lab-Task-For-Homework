﻿using HotelApp.Sattar.DAL;
using HotelApp.Sattar.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelApp.Sattar
{
    public partial class StudentForm : Form
    {
        StudentDTO studentDTO;
        GroupDTO groupDTO;

        List<Group> groupsFromDB;

        public StudentForm()
        {
            InitializeComponent();
            studentDTO = new StudentDTO();
            groupDTO = new GroupDTO();
            groupsFromDB = new List<Group>();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {

            string groupName = cbxGroup.SelectedItem.ToString();

            Group group = groupsFromDB.FirstOrDefault(g => g.Name == groupName);

            //int groupId = groupDTO.GetIdByName(groupName);

            Student student = new Student()
            {
                Firstname = txtFname.Text,
                Lastname = txtLname.Text,
                Email = txtEmail.Text,
                //GroupId = groupId
                GroupId = group.Id

            };

            bool isCreated = studentDTO.Create(student);
            if (isCreated)
            {
                MessageBox.Show("Student created");
            }
            else
            {
                MessageBox.Show("Student NOT created");

            }

        }

        private void StudentForm_Load(object sender, EventArgs e)
        {
            groupsFromDB = groupDTO.ReadAll();
            foreach (Group item in groupsFromDB)
            {
                cbxGroup.Items.Add(item.Name);
            }

        }
    }
}
